# Find My Block

Campus navigation prototype for Burnside High School.

## GitHub Pages

Upload all files in this folder to the repository root, then enable GitHub Pages from the `main` branch. The site must be opened over HTTPS for browser location permission.

## Live location

Press the target button (`◎`) on the map and allow location access. The map is calibrated with the supplied Canteen, Library, and P GPS points. GPS accuracy can be reduced near buildings; the blue arrow is the device position and the translucent circle is the reported accuracy.
