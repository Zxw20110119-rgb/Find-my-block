/* Coordinates traced from the user's red-line map; units are image pixels, not metres. */
const nodes={
w0:[437,390],w1:[480,390],w2:[597,390],w3:[695,390],
n0:[695,245],n2:[795,245],nTurn:[808,270],n3:[858,266],n4:[887,251],n7:[894,151],
g0:[858,373],gHub:[858,317],g1:[805,373],b0:[695,430],b1:[805,430],a0:[597,535],a1:[695,535],a2:[597,583],e0:[480,587],e1:[433,587],e2:[433,562],m0:[591,587],m2:[591,675],m3:[591,707],m4:[591,908],
c0:[805,535],cTop:[805,485],cEast:[983,485],c1:[805,594],c2:[695,594],xBridge:[695,375],xg:[805,375],q0:[695,657],q0w:[657,657],q1:[805,657],q1e:[900,657],q1n:[900,605],south:[657,707],
s0:[887,272],s2:[948,317],s4:[983,368],s5:[983,585],s6:[935,595],s6h:[983,595]
};
// Extra walkways from the latest red-line markup: X→G and the east side of C Block.
const chains=[
["w0","w1","w2","w3"],["w1","e0"],["w2","a0","a2"],["a2","m0"],["a0","a1"],
["e2","e1","e0","m0","m2","m3","m4"],["m3","south","q0w","q0"],
["q0","c2","a1","b0","w3","n0"],["b0","b1"],["b1","xg","g1","g0","gHub","n3"],["w3","xBridge","xg"],["b1","c0","cTop","cEast"],["cTop","c1"],["c1","q1"],
["c2","c1"],["q0","q1","q1e","q1n","s6","s6h","s5"],
["n0","n2","nTurn","n3","n4","n7"],["n3","s0","s2","s4","cEast","s5"]
];
const places={
a:{name:"A Block",access:["a0","a1","q0","m2"]},
b:{name:"B Block",access:["b0","b1","a1","c1"]},
c:{name:"C Block",access:["c0","cTop","cEast","c1","s5"]},
d:{name:"D Block",access:["q1e"]},
e:{name:"E Block",access:["w1","w2","e0"]},
g:{name:"G Block",access:["g0","g1","gHub","s4"]},
h:{name:"H Block",access:["n0","n2"]},
k:{name:"K Block",access:["n3","n4","n7"]},
l:{name:"L Block",access:["w2","a0","a1"]},
m:{name:"M Block",access:["m0","m2","m3"]},
n:{name:"N Block",access:["n0","w3","g0"]},
x:{name:"X Block",access:["w3","b0","b1"]},
library:{name:"Library",zh:"图书馆",access:["q1"]},
international:{name:"International Office",zh:"国际部",access:["q0","south"]},
reception:{name:"Main Reception · nearby path",zh:"接待处附近步道",access:["south"]},
canteen:{name:"Canteen",zh:"食堂",access:["s6"]},
hunter:{name:"Hunter Gym",access:["s2","s4"]},
aurora:{name:"Aurora Centre",access:["m4"]},
rakipaoa:{name:"Rakipaoa",access:["w0","e2"]},
pukehinau:{name:"Pukehinau",access:["w3","n0"]}
};
// GPS calibration points supplied by the user. Map coordinates are pixels in the
// 1536×1086 campus image; the P point is the left-hand P/Staff Parking marker.
const gpsOrigin={lat:-43.5073722222,lon:172.5773972222};
const gpsAnchors=[
  {lat:-43.5073722222,lon:172.5773972222,map:[935,595],label:"Canteen"},
  {lat:-43.5076472222,lon:172.5768916667,map:[805,657],label:"Library"},
  {lat:-43.50705,lon:172.5758388889,map:[400,720],label:"P"}
];
const gpsEastScale=111320*Math.cos(gpsOrigin.lat*Math.PI/180),gpsNorthScale=110540;
gpsAnchors.forEach(point=>{point.e=(point.lon-gpsOrigin.lon)*gpsEastScale;point.n=(point.lat-gpsOrigin.lat)*gpsNorthScale;});
function solveGpsAxis(axis){
  const a=gpsAnchors.map(point=>[point.e,point.n,1]),b=gpsAnchors.map(point=>point.map[axis]);
  for(let i=0;i<3;i++){
    let pivot=i;
    for(let row=i+1;row<3;row++)if(Math.abs(a[row][i])>Math.abs(a[pivot][i]))pivot=row;
    [a[i],a[pivot]]=[a[pivot],a[i]];[b[i],b[pivot]]=[b[pivot],b[i]];
    for(let row=i+1;row<3;row++){const factor=a[row][i]/a[i][i];for(let col=i;col<3;col++)a[row][col]-=factor*a[i][col];b[row]-=factor*b[i];}
  }
  const out=[0,0,0];
  for(let i=2;i>=0;i--){let value=b[i];for(let col=i+1;col<3;col++)value-=a[i][col]*out[col];out[i]=value/a[i][i];}
  return out;
}
const gpsX=solveGpsAxis(0),gpsY=solveGpsAxis(1);
const gpsToMap=(lat,lon)=>{const e=(lon-gpsOrigin.lon)*gpsEastScale,n=(lat-gpsOrigin.lat)*gpsNorthScale;return [gpsX[0]*e+gpsX[1]*n+gpsX[2],gpsY[0]*e+gpsY[1]*n+gpsY[2]];};
const mapHeadingFromGps=heading=>{const radians=heading*Math.PI/180,east=Math.sin(radians),north=Math.cos(radians),dx=gpsX[0]*east+gpsX[1]*north,dy=gpsY[0]*east+gpsY[1]*north;return Math.atan2(dx,-dy)*180/Math.PI;};
const gpsPixelScale=Math.sqrt((Math.hypot(gpsX[0],gpsY[0])**2+Math.hypot(gpsX[1],gpsY[1])**2)/2);
const graph=Object.fromEntries(Object.keys(nodes).map(k=>[k,[]]));
const len=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
chains.forEach(chain=>chain.slice(1).forEach((b,i)=>{const a=chain[i],d=len(nodes[a],nodes[b]);graph[a].push([b,d]);graph[b].push([a,d]);}));
function shortest(from,to){
const dist=Object.fromEntries(Object.keys(nodes).map(k=>[k,Infinity])),prev={},queue=new Set(Object.keys(nodes));
places[from].access.forEach(k=>dist[k]=0);
let end;
while(queue.size){let u=[...queue].reduce((a,b)=>dist[a]<dist[b]?a:b);if(!Number.isFinite(dist[u]))break;queue.delete(u);if(places[to].access.includes(u)){end=u;break;}
for(const [v,w]of graph[u])if(queue.has(v)&&dist[u]+w<dist[v]){dist[v]=dist[u]+w;prev[v]=u;}}
if(!end)throw Error("No connected route");
const path=[end];while(prev[path[0]])path.unshift(prev[path[0]]);
return path;
}
const $=id=>document.getElementById(id);
let lang="en",path=[],points=[],total=0,travel=0,playing=false,started=false,follow=true,zoom=1,pan=[0,0],angle=0,last=0,velocity=0,lastInstruction="",lastIcon="";
let locationActive=false,locationWatch=null,liveLocation=null,locationMessage="",headingHandler=null;
const text=(zh,en)=>lang==="zh"?zh:en;
const name=k=>lang==="zh"?(places[k].zh||places[k].name):places[k].name;
function options(){for(const id of ["from","to"]){const old=$(id).value;$(id).replaceChildren(...Object.keys(places).map(k=>new Option(name(k),k)));if(old)$(id).value=old;}}
function plan(){
playing=false;started=false;travel=0;velocity=0;follow=Boolean(locationActive&&liveLocation);pan=[0,0];zoom=1;
path=shortest($("from").value,$("to").value);points=path.map(k=>nodes[k]);total=points.slice(1).reduce((s,p,i)=>s+len(points[i],p),0);
const poly=points.map(p=>p.join(",")).join(" ");$("route").setAttribute("points",poly);$("halo").setAttribute("points",poly);
for(const line of [$("route"),$("halo")]){line.classList.remove("route-draw");void line.getBoundingClientRect();line.classList.add("route-draw");}
const end=points.at(-1);$("destination").setAttribute("transform","translate("+end.join(" ")+")");
const url=new URL(location.href);url.searchParams.set("start",$("from").value);url.searchParams.set("end",$("to").value);history.replaceState(null,"",url);
const card=$("bottomCard");card.classList.remove("card-change");void card.offsetWidth;card.classList.add("card-change");
update();
}
function at(distance){
let remaining=distance;
for(let i=0;i<points.length-1;i++){const a=points[i],b=points[i+1],d=len(a,b);if(d<.001)continue;if(remaining<=d||i===points.length-2){const t=Math.min(1,remaining/d);return {p:[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t],heading:Math.atan2(b[0]-a[0],-(b[1]-a[1]))*180/Math.PI,index:i};}remaining-=d;}
return {p:points[0]||[0,0],heading:0,index:0};
}
function normalizeHeading(value){return Number.isFinite(value)&&value>=0?((value%360)+360)%360:null;}
function onOrientation(event){
  const compass=normalizeHeading(event.webkitCompassHeading);
  const absolute=compass===null&&event.absolute&&Number.isFinite(event.alpha)?normalizeHeading(360-event.alpha):compass;
  if(absolute===null||!locationActive||!liveLocation||liveLocation.gpsHeading!==null)return;
  liveLocation.heading=mapHeadingFromGps(absolute);update(.05);
}
async function enableHeading(){
  if(headingHandler)return;
  const Orientation=window.DeviceOrientationEvent;
  if(typeof Orientation==="undefined")return;
  if(typeof Orientation.requestPermission==="function"){
    const permission=await Orientation.requestPermission();
    if(permission!=="granted")return;
  }
  headingHandler=onOrientation;
  window.addEventListener("deviceorientationabsolute",headingHandler,true);
  window.addEventListener("deviceorientation",headingHandler,true);
}
function disableHeading(){
  if(!headingHandler)return;
  window.removeEventListener("deviceorientationabsolute",headingHandler,true);
  window.removeEventListener("deviceorientation",headingHandler,true);
  headingHandler=null;
}
function onLocation(position){
  const coords=position.coords,p=gpsToMap(coords.latitude,coords.longitude);
  if(!p.every(Number.isFinite))return;
  const gpsHeading=normalizeHeading(coords.heading),previous=liveLocation?.heading??0;
  liveLocation={p,accuracy:Number.isFinite(coords.accuracy)?Math.max(1,coords.accuracy):20,heading:gpsHeading===null?previous:mapHeadingFromGps(gpsHeading),gpsHeading};
  locationMessage="";follow=true;update(.08);
}
function onLocationError(error){
  const message=error.code===1?text("定位权限被拒绝。请在浏览器设置中允许定位。","Location permission was denied. Allow it in your browser settings."):error.code===2?text("暂时无法获取位置。","Location is temporarily unavailable."):text("定位请求超时，正在重试。","Location timed out; retrying.");
  if(error.code===1)stopLocation(message);else{locationMessage=message;update(.08);}
}
function stopLocation(message=""){
  if(locationWatch!==null&&navigator.geolocation)navigator.geolocation.clearWatch(locationWatch);
  locationWatch=null;locationActive=false;liveLocation=null;locationMessage=message;disableHeading();update(.08);
}
async function startLocation(){
  if(locationActive){stopLocation();return;}
  if(!navigator.geolocation){locationMessage=text("此浏览器不支持定位。","This browser does not support location.");update(.08);return;}
  locationActive=true;liveLocation=null;locationMessage=text("正在获取位置…","Locating…");follow=true;pan=[0,0];zoom=1;
  try{await enableHeading();}catch{}
  locationWatch=navigator.geolocation.watchPosition(onLocation,onLocationError,{enableHighAccuracy:true,maximumAge:2000,timeout:10000});
  update(.12);
}
function activeState(){return locationActive&&liveLocation?{p:liveLocation.p,heading:liveLocation.heading,index:0}:at(travel);}
function camera(state,dt=.016){
const w=$("map").clientWidth,h=$("map").clientHeight,mobile=w<=760;
let scale,cx,cy,px,py,rotation;
const canFollow=(started&&follow)||(locationActive&&Boolean(liveLocation)&&follow);
if(canFollow){
scale=(mobile?1.45:1.8)*zoom;cx=mobile?w*.46:384+(w-384)*.5;cy=mobile?h*.57:h*.62;[px,py]=state.p;
const desired=-state.heading;const turn=((desired-angle+540)%360)-180;angle+=turn*(1-Math.exp(-Math.min(dt,.12)*8));rotation=angle;
}else{
const xs=points.map(p=>p[0]),ys=points.map(p=>p[1]);const bw=Math.max(220,Math.max(...xs)-Math.min(...xs)+170),bh=Math.max(220,Math.max(...ys)-Math.min(...ys)+170);
scale=Math.min((mobile?w-40:w-470)/bw,(mobile?Math.max(180,h-480):h-220)/bh,1.6)*zoom;
cx=mobile?w*.5:410+(w-410)*.5;cy=mobile?280+Math.max(180,h-480)*.5:h*.53;px=(Math.min(...xs)+Math.max(...xs))/2;py=(Math.min(...ys)+Math.max(...ys))/2;rotation=0;
angle=0;
}
$("world").style.transform="translate("+(cx+pan[0])+"px,"+(cy+pan[1])+"px) rotate("+rotation+"deg) scale("+scale+") translate("+(-px)+"px,"+(-py)+"px)";
$("follow").classList.toggle("active",canFollow);$("locate").classList.toggle("active",locationActive);$("locate").setAttribute("aria-pressed",locationActive?"true":"false");
}
function update(dt=.016){
const state=activeState(),arrived=travel>=total,from=$("from").value,to=$("to").value;
$("position").setAttribute("transform","translate("+state.p.join(" ")+") rotate("+state.heading+")");$("position").style.opacity=locationActive&&!liveLocation?"0":"1";$("accuracy").setAttribute("r",locationActive&&liveLocation?Math.max(8,liveLocation.accuracy*gpsPixelScale):0);
$("tripTitle").textContent=name(to);$("tripSubtitle").textContent=text("从 ","From ")+name(from);
$("language").textContent=lang==="zh"?"EN":"中文";
$("start").textContent=arrived?text("已到达","Arrived"):playing?text("暂停演示","Pause demo"):started?text("继续演示","Resume demo"):text("开始模拟导航","Start demo");
$("start").disabled=arrived;
$("reset").textContent=text("重新规划","Reset");
$("note").textContent=locationActive?text("正在使用设备定位。建筑附近的 GPS 可能有误差。","Live location from your device. GPS accuracy may vary near buildings."):text("按你标注的步道规划。点击定位按钮可使用设备 GPS。","Uses your marked paths. Tap the location button to use device GPS.");
$("badge").textContent=locationActive?(liveLocation?text("实时定位 · ±"+Math.round(liveLocation.accuracy)+"米","GPS · ±"+Math.round(liveLocation.accuracy)+" m"):locationMessage||text("正在定位…","Locating…")):started?text("模拟导航 · 非实时定位","SIMULATION · Not live location"):text("路线预览 · 未开启定位","Route preview · Location off");
$("progressWrap").hidden=!started;document.body.classList.toggle("simulating",started);
$("progressLabel").textContent=text("拖动预览行程","Scrub through the route")+" · "+(total?Math.round(travel/total*100):100)+"%";
$("progress").value=total?Math.round(travel/total*1000):1000;
let instruction=text("沿蓝色路线前行","Follow the blue route"),icon="↑";
if(arrived){instruction=from===to?text("你已在目的地","Already at destination"):text("已到达建筑旁步道","At the path beside your block");icon="✓";}
else if(started&&state.index<points.length-2){
const a=points[state.index],b=points[state.index+1],c=points[state.index+2];
const h1=Math.atan2(b[1]-a[1],b[0]-a[0]),h2=Math.atan2(c[1]-b[1],c[0]-b[0]);const turn=((h2-h1)*180/Math.PI+540)%360-180;
if(Math.abs(turn)>30){instruction=turn>0?text("前方右转","Turn right ahead"):text("前方左转","Turn left ahead");icon=turn>0?"↱":"↰";}
else instruction=text("继续直行","Continue straight");
}
$("instruction").textContent=instruction;$("turnIcon").textContent=icon;
if(instruction!==lastInstruction||icon!==lastIcon){const guidance=$("guidance");guidance.classList.remove("guidance-change");void guidance.offsetWidth;guidance.classList.add("guidance-change");lastInstruction=instruction;lastIcon=icon;}
$("next").textContent=arrived?name(to):text("前往 ","Towards ")+name(to);
camera(state,dt);
}
$("network").innerHTML=chains.map(c=>'<polyline points="'+c.map(k=>nodes[k].join(",")).join(" ")+'"/>').join("");
options();
const params=new URLSearchParams(location.search);
$("from").value=places[params.get("start")]?params.get("start"):"library";
$("to").value=places[params.get("end")]?params.get("end"):"k";
$("from").onchange=plan;$("to").onchange=plan;
$("swap").onclick=()=>{const a=$("from").value;$("from").value=$("to").value;$("to").value=a;plan();};
$("language").onclick=()=>{lang=lang==="zh"?"en":"zh";document.documentElement.lang=lang==="zh"?"zh-CN":"en";options();update(.16);};
$("start").onclick=()=>{if(travel>=total)return;started=true;playing=!playing;follow=true;pan=[0,0];last=0;update(.16);};
$("reset").onclick=plan;
$("progress").oninput=()=>{playing=false;travel=Number($("progress").value)/1000*total;update(.12);};
$("overview").onclick=()=>{follow=false;pan=[0,0];zoom=1;update(.18);};
$("follow").onclick=()=>{started=true;follow=true;pan=[0,0];update(.18);};
$("locate").onclick=startLocation;
$("plus").onclick=()=>{zoom=Math.min(3,zoom*1.25);update(.18);};
$("minus").onclick=()=>{zoom=Math.max(.45,zoom/1.25);update(.18);};
let drag=null;
$("map").onpointerdown=e=>{drag=[e.clientX,e.clientY,...pan];$("map").setPointerCapture(e.pointerId);};
$("map").onpointermove=e=>{if(!drag)return;pan=[drag[2]+e.clientX-drag[0],drag[3]+e.clientY-drag[1]];camera(activeState(),.05);};
$("map").onpointerup=()=>drag=null;$("map").onpointercancel=()=>drag=null;
window.addEventListener("resize",()=>camera(activeState()));
function tick(now){const dt=last?Math.min((now-last)/1000,.12):0;if(playing&&dt){const response=1-Math.exp(-dt*6);velocity+=(30-velocity)*response;travel=Math.min(total,travel+velocity*dt);if(travel>=total){playing=false;velocity=0;}update(dt);}else if(!playing&&velocity>0.05){velocity*=Math.exp(-dt*9);}last=now;requestAnimationFrame(tick);}
plan();requestAnimationFrame(tick);
if(document.modelContext?.registerTool){try{Promise.resolve(document.modelContext.registerTool({name:"plan_campus_route",description:"Plan a campus route along the marked walkways; location is simulated.",inputSchema:{type:"object",properties:{start:{type:"string",enum:Object.keys(places)},destination:{type:"string",enum:Object.keys(places)}},required:["start","destination"],additionalProperties:false},annotations:{readOnlyHint:false},execute(input){if(!input||!places[input.start]||!places[input.destination])throw Error("Unknown location");$("from").value=input.start;$("to").value=input.destination;plan();return {start:input.start,destination:input.destination,simulation:true};}})).catch(()=>{});}catch{}}
